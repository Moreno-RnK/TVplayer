﻿window.WEBOS_ZIP_CONFIG = {
  startUrl: "https://automartinauto.pt/tvmedia/player-lg-legacy.html?device=tv-xpeng",
  launchDelayMs: 12000
};

