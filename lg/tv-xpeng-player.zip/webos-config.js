window.WEBOS_ZIP_CONFIG = {
  startUrl: "https://tv-media.vercel.app/player-lg.html?device=tv-xpeng",
  launchDelayMs: 1200
};
