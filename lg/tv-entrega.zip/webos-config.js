window.WEBOS_ZIP_CONFIG = {
  startUrl: "https://automartinauto.pt/tvmedia/player-lg-legacy.html?device=tv-entrega",
  launchDelayMs: 1200
};
